package com.autoclickerpro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scenarios")
data class Scenario(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val pointsJson: String,
    val intervalMs: Long,
    val repeatCount: Int,
    val durationSec: Int,
    val startDelaySec: Int,
    val createdAt: Long,
    val lastUsedAt: Long = 0L
) {
    fun parsePoints(): List<ClickPoint> = ClickPoint.listFromJson(pointsJson)
}
