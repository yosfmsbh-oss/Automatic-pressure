package com.autoclickerpro.data

import org.json.JSONArray
import org.json.JSONObject

/** نقطة ضغط: الإحداثيات مركز النقطة بالبكسل. delayMs = 0 يعني استخدام الفاصل الافتراضي. */
data class ClickPoint(val x: Int, val y: Int, val delayMs: Long = 0L) {
    companion object {
        fun listToJson(list: List<ClickPoint>): String {
            val arr = JSONArray()
            list.forEach { arr.put(JSONObject().put("x", it.x).put("y", it.y).put("d", it.delayMs)) }
            return arr.toString()
        }

        fun listFromJson(json: String?): List<ClickPoint> {
            if (json.isNullOrBlank()) return emptyList()
            return try {
                val arr = JSONArray(json)
                (0 until arr.length()).mapNotNull { i ->
                    val o = arr.optJSONObject(i) ?: return@mapNotNull null
                    ClickPoint(o.optInt("x"), o.optInt("y"), o.optLong("d", 0L))
                }
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
}
