package com.autoclickerpro.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.autoclickerpro.engine.ClickEngine
import com.autoclickerpro.engine.ClickerRuntime
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * تنفّذ النقرات فقط. لا تقرأ محتوى الشاشة؛ تأخذ من حدث تغيّر النافذة اسم الحزمة فقط
 * لتفعيل الحماية من التطبيقات الحساسة.
 */
class ClickerAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClickerAccessibilityService? = null
    }

    @Volatile
    var foregroundPackage: String? = null

    override fun onServiceConnected() {
        instance = this
        ClickerRuntime.state.update { it.copy(a11y = true) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString().orEmpty()
        // نتجاهل لوحة المفاتيح وواجهة النظام حتى لا تحجب اسم التطبيق الحقيقي
        if (cls.contains("SoftInputWindow") || pkg == "com.android.systemui") return
        foregroundPackage = pkg
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        lost()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        lost()
        super.onDestroy()
    }

    private fun lost() {
        instance = null
        foregroundPackage = null
        ClickerRuntime.state.update { it.copy(a11y = false) }
        ClickEngine.onServiceLost()
    }

    /** ينفّذ نقرة ويُرجع true فقط إذا اكتملت فعلاً. */
    suspend fun tap(x: Float, y: Float, durationMs: Long): Boolean =
        suspendCancellableCoroutine { cont ->
            val path = Path().apply { moveTo(x, y) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
                .build()
            val cb = object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }
            val dispatched = dispatchGesture(gesture, cb, null)
            if (!dispatched && cont.isActive) cont.resume(false)
        }
}
