package com.autoclickerpro.engine

import android.os.SystemClock
import com.autoclickerpro.App
import com.autoclickerpro.data.ClickPoint
import com.autoclickerpro.service.ClickerAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.coroutineContext

/**
 * محرك الضغط: حلقة Coroutines على الخيط الرئيسي (الانتظار بـ delay لا يحجب الواجهة)،
 * وكل ضغطة تُنفَّذ عبر AccessibilityService وتُعدّ فقط عند اكتمالها فعلاً.
 */
object ClickEngine {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null

    @Volatile
    private var paused = false
    private var accumMs = 0L
    private var resumeAt = 0L

    /** تضبطه اللوحة العائمة: يعيد مواضع النقاط الحالية. */
    @Volatile
    var pointsProvider: (() -> List<ClickPoint>)? = null

    val isActive: Boolean get() = job?.isActive == true

    private fun elapsed(): Long =
        accumMs + if (paused) 0L else (SystemClock.elapsedRealtime() - resumeAt)

    private fun emit(e: EngineEvent) {
        ClickerRuntime.events.tryEmit(e)
    }

    fun start(cfg: EngineConfig): Boolean {
        if (isActive) return false
        if (ClickerAccessibilityService.instance == null) {
            emit(EngineEvent.A11Y_LOST); return false
        }
        if (pointsProvider?.invoke().isNullOrEmpty()) {
            emit(EngineEvent.NO_POINTS); return false
        }
        paused = false
        accumMs = 0L
        resumeAt = SystemClock.elapsedRealtime()
        ClickerRuntime.state.update {
            it.copy(engine = EngineState.COUNTDOWN, clicks = 0L, elapsedMs = 0L, countdown = cfg.startDelaySec)
        }
        Feedback.pulse(cfg.vibrate, cfg.sound)
        val j = scope.launch(start = CoroutineStart.LAZY) { run(cfg, coroutineContext[Job]) }
        job = j
        j.start()
        return true
    }

    fun pause() {
        if (ClickerRuntime.state.value.engine == EngineState.RUNNING) setPaused(true)
    }

    fun resume() {
        if (ClickerRuntime.state.value.engine == EngineState.PAUSED) setPaused(false)
    }

    /** إيقاف فوري (يُستخدم أيضاً كزر الطوارئ). */
    fun stop() {
        val j = job
        if (j != null && j.isActive) {
            j.cancel()
            ClickerRuntime.state.update { it.copy(engine = EngineState.IDLE, countdown = 0) }
        }
    }

    /** يُستدعى عند انقطاع خدمة إمكانية الوصول. */
    fun onServiceLost() {
        if (isActive) {
            emit(EngineEvent.A11Y_LOST)
            stop()
        }
    }

    private fun setPaused(p: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (p && !paused) {
            accumMs += now - resumeAt
            paused = true
            ClickerRuntime.state.update { it.copy(engine = EngineState.PAUSED) }
        } else if (!p && paused) {
            resumeAt = now
            paused = false
            ClickerRuntime.state.update { it.copy(engine = EngineState.RUNNING) }
        }
    }

    private suspend fun awaitReady(cfg: EngineConfig): ClickerAccessibilityService? {
        while (true) {
            coroutineContext.ensureActive()
            val svc = ClickerAccessibilityService.instance ?: return null
            if (paused) {
                delay(40); continue
            }
            if (cfg.guard && SensitiveGuard.isBlocked(svc.foregroundPackage)) {
                setPaused(true)
                emit(EngineEvent.GUARD_PAUSED)
                continue
            }
            return svc
        }
    }

    private suspend fun run(cfg: EngineConfig, me: Job?) {
        var clicks = 0L
        var failStreak = 0
        var endEvent: EngineEvent? = null
        val ticker = scope.launch {
            while (true) {
                delay(250)
                ClickerRuntime.state.update { it.copy(elapsedMs = elapsed()) }
            }
        }
        try {
            var s = cfg.startDelaySec
            while (s > 0) {
                ClickerRuntime.state.update { it.copy(countdown = s) }
                delay(1000)
                s--
            }
            accumMs = 0L
            resumeAt = SystemClock.elapsedRealtime()
            ClickerRuntime.state.update { it.copy(engine = EngineState.RUNNING, countdown = 0) }

            var rounds = 0
            loop@ while (true) {
                coroutineContext.ensureActive()
                val pts = pointsProvider?.invoke().orEmpty()
                if (pts.isEmpty()) {
                    endEvent = EngineEvent.NO_POINTS; break@loop
                }
                for (p in pts) {
                    val svc = awaitReady(cfg)
                    if (svc == null) {
                        endEvent = EngineEvent.A11Y_LOST; break@loop
                    }
                    if (cfg.durationSec > 0 && elapsed() >= cfg.durationSec * 1000L) {
                        endEvent = EngineEvent.FINISHED; break@loop
                    }
                    val d = if (p.delayMs > 0) p.delayMs else cfg.intervalMs
                    val dur = EngineMath.tapDurationMs(d)
                    val ok = withTimeoutOrNull(1500L) { svc.tap(p.x.toFloat(), p.y.toFloat(), dur) } ?: false
                    if (ok) {
                        clicks++
                        failStreak = 0
                        ClickerRuntime.state.update { it.copy(clicks = clicks) }
                    } else if (++failStreak >= 15) {
                        endEvent = EngineEvent.TAP_FAILED; break@loop
                    }
                    delay(EngineMath.restAfterTap(d))
                }
                rounds++
                if (cfg.repeatCount > 0 && rounds >= cfg.repeatCount) {
                    endEvent = EngineEvent.FINISHED; break@loop
                }
            }
        } finally {
            ticker.cancel()
            val ms = elapsed()
            if (job === me) {
                paused = false
                ClickerRuntime.state.update {
                    it.copy(engine = EngineState.IDLE, countdown = 0, clicks = clicks, elapsedMs = ms)
                }
                Feedback.pulse(cfg.vibrate, cfg.sound)
                endEvent?.let { emit(it) }
            }
            if (clicks > 0) {
                val app = App.instance
                app.appScope.launch { app.repo.addSession(clicks, ms) }
            }
        }
    }
}
