package com.autoclickerpro.ui

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.autoclickerpro.App
import com.autoclickerpro.data.ClickerSettings
import com.autoclickerpro.data.Scenario
import com.autoclickerpro.engine.ClickEngine
import com.autoclickerpro.engine.ClickerRuntime
import com.autoclickerpro.engine.EngineConfig
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val a = application as App
    private val repo = a.repo
    private val dao = a.db.scenarios()

    val settings: StateFlow<ClickerSettings> =
        repo.flow.stateIn(viewModelScope, SharingStarted.Eagerly, ClickerSettings())
    val scenarios: StateFlow<List<Scenario>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val runtime = ClickerRuntime.state

    val overlayGranted = MutableStateFlow(false)
    val notifGranted = MutableStateFlow(true)

    fun refreshPermissions() {
        overlayGranted.value = Settings.canDrawOverlays(a)
        notifGranted.value = Build.VERSION.SDK_INT < 33 ||
                a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    fun update(t: (ClickerSettings) -> ClickerSettings) = viewModelScope.launch { repo.update(t) }

    fun resetSettings() = viewModelScope.launch { repo.resetSettings() }

    /** بدء الضغط من الشاشة الرئيسية مع مهلة أمان لا تقل عن 3 ثوانٍ. */
    fun startClicking(): Boolean = ClickEngine.start(EngineConfig.from(settings.value, 3))

    fun newSession() {
        ClickEngine.stop()
        ClickerRuntime.state.update { it.copy(clicks = 0L, elapsedMs = 0L, countdown = 0) }
    }

    fun saveScenario(s: Scenario) = viewModelScope.launch { dao.upsert(s) }

    fun deleteScenario(s: Scenario) = viewModelScope.launch { dao.delete(s.id) }

    fun duplicateScenario(s: Scenario, suffix: String) = viewModelScope.launch {
        dao.upsert(s.copy(id = 0, name = "${s.name} $suffix", createdAt = System.currentTimeMillis(), lastUsedAt = 0L))
    }

    private suspend fun apply(s: Scenario) {
        repo.update {
            it.copy(
                intervalMs = s.intervalMs, repeatCount = s.repeatCount, durationSec = s.durationSec,
                startDelaySec = s.startDelaySec, pointsJson = s.pointsJson, activeScenarioId = s.id
            )
        }
        if (s.id != 0L) dao.touch(s.id, System.currentTimeMillis())
    }

    /** يحمّل السيناريو في اللوحة دون تشغيل الضغط. */
    fun loadScenario(s: Scenario, actions: Actions) = viewModelScope.launch {
        ClickEngine.stop()
        apply(s)
        if (ClickerRuntime.state.value.panelAlive) actions.reloadPanel()
    }

    /** تشغيل سيناريو: تحميل ثم بدء الضغط (بمهلة 3 ثوانٍ على الأقل) إن كانت اللوحة تعمل. */
    fun runScenario(s: Scenario, actions: Actions) = viewModelScope.launch {
        ClickEngine.stop()
        apply(s)
        if (ClickerRuntime.state.value.panelAlive) {
            actions.reloadPanel()
            delay(600)
            if (ClickEngine.start(EngineConfig.from(repo.flow.first(), 3))) actions.minimize()
        } else {
            actions.launchPanel()
        }
    }
}
