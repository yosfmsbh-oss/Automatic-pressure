package com.autoclickerpro.engine

import java.util.Locale

/** منطق حسابي بحت (قابل للاختبار بدون أندرويد). */
object EngineMath {
    const val MIN_INTERVAL = 10L

    fun clampInterval(v: Long): Long = v.coerceAtLeast(MIN_INTERVAL)
    fun cps(intervalMs: Long): Double = 1000.0 / clampInterval(intervalMs)
    fun tapDurationMs(intervalMs: Long): Long = (clampInterval(intervalMs) / 2).coerceIn(1L, 40L)
    fun restAfterTap(intervalMs: Long): Long =
        (clampInterval(intervalMs) - tapDurationMs(intervalMs)).coerceAtLeast(0L)

    fun formatDuration(ms: Long): String {
        val t = (ms / 1000).coerceAtLeast(0)
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }
}
