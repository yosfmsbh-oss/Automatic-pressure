package com.autoclickerpro.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ScenarioDao {
    @Query("SELECT * FROM scenarios ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<Scenario>>

    @Query("SELECT * FROM scenarios ORDER BY createdAt DESC")
    suspend fun getAll(): List<Scenario>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(s: Scenario): Long

    @Query("DELETE FROM scenarios WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE scenarios SET lastUsedAt = :t WHERE id = :id")
    suspend fun touch(id: Long, t: Long)
}
