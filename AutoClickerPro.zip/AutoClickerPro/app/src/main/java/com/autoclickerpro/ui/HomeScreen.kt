package com.autoclickerpro.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.autoclickerpro.R
import com.autoclickerpro.data.ClickPoint
import com.autoclickerpro.engine.ClickEngine
import com.autoclickerpro.engine.EngineMath
import com.autoclickerpro.engine.EngineState
import java.util.Locale

@Composable
fun HomeScreen(vm: MainViewModel, actions: Actions, pad: PaddingValues) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    val scenarios by vm.scenarios.collectAsStateWithLifecycle()
    val overlay by vm.overlayGranted.collectAsStateWithLifecycle()
    val notif by vm.notifGranted.collectAsStateWithLifecycle()
    var showDisclosure by remember { mutableStateOf(false) }

    val ready = rt.a11y && overlay
    val engine = rt.engine
    val active = engine == EngineState.RUNNING || engine == EngineState.COUNTDOWN

    fun onPower() {
        when {
            !rt.a11y -> showDisclosure = true
            !overlay -> actions.openOverlay()
            !rt.panelAlive -> actions.launchPanel()
            engine == EngineState.IDLE -> if (vm.startClicking()) actions.minimize()
            engine == EngineState.PAUSED -> ClickEngine.resume()
            else -> ClickEngine.stop()
        }
    }

    val glyph = when {
        !ready -> "!"
        active -> "■"
        else -> "▶"
    }
    val powerLabel = when {
        !ready -> R.string.pw_setup
        !rt.panelAlive -> R.string.pw_launch
        engine == EngineState.IDLE -> R.string.pw_start
        engine == EngineState.PAUSED -> R.string.pw_resume
        else -> R.string.pw_stop
    }

    val shownClicks = if (rt.clicks > 0 || engine != EngineState.IDLE) rt.clicks else s.lastSessionClicks
    val shownMs = if (rt.elapsedMs > 0 || engine != EngineState.IDLE) rt.elapsedMs else s.lastSessionMs

    Column(
        Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // الترويسة
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_logo_mark), contentDescription = null, modifier = Modifier.size(40.dp))
            Spacer(Modifier.width(10.dp))
            Text(
                buildAnnotatedString {
                    append("Auto Clicker ")
                    withStyle(SpanStyle(color = MaterialTheme.colorScheme.primary)) { append("Pro") }
                },
                style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            StatusChip(rt.status)
        }

        if (!ready || !notif) {
            PermissionsCard(rt.a11y, overlay, notif, actions, onA11yClick = { showDisclosure = true })
        }

        // زر التشغيل والعداد
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            PowerButton(rt.status, engine, glyph) { onPower() }
            Text(
                stringResource(powerLabel), color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(10.dp))
            Text(
                shownClicks.toString(), fontSize = 52.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                if (rt.countdown > 0) "⏳ ${rt.countdown}" else stringResource(R.string.clicks_unit),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (engine != EngineState.IDLE) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { if (engine == EngineState.PAUSED) ClickEngine.resume() else ClickEngine.pause() },
                    modifier = Modifier.weight(1f)
                ) { Text(stringResource(if (engine == EngineState.PAUSED) R.string.act_resume else R.string.act_pause)) }
                FilledTonalButton(onClick = { ClickEngine.stop() }, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.act_stop))
                }
            }
        }

        // بطاقة السرعة
        AcpCard(Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.speed_title), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    stringResource(R.string.speed_cps, String.format(Locale.US, "%.1f", EngineMath.cps(s.intervalMs))),
                    fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                )
                Text(
                    stringResource(R.string.speed_interval, EngineMath.clampInterval(s.intervalMs).toInt()),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1000L to R.string.speed_slow, 200L to R.string.speed_mid, 50L to R.string.speed_fast)
                    .forEach { (v, l) ->
                        FilterChip(
                            selected = s.intervalMs == v,
                            onClick = { vm.update { it.copy(intervalMs = v) } },
                            label = { Text(stringResource(l)) }
                        )
                    }
            }
        }

        // مدة التشغيل + الإجمالي
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AcpCard(Modifier.weight(1f).fillMaxHeight()) {
                Text(stringResource(R.string.duration_title), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(EngineMath.formatDuration(shownMs), fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            AcpCard(Modifier.weight(1f).fillMaxHeight()) {
                Text(stringResource(R.string.total_title), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(s.totalClicks.toString(), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(
                    stringResource(R.string.last_session, s.lastSessionClicks.toInt()),
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp
                )
            }
        }

        OutlinedButton(
            onClick = {
                vm.newSession()
                if (ready && !rt.panelAlive) actions.launchPanel()
            },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(stringResource(R.string.new_session)) }

        if (rt.panelAlive) {
            TextButton(onClick = actions.quitPanel, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.close_panel))
            }
        }

        // آخر السيناريوهات
        SectionTitle(stringResource(R.string.recent_title))
        val recent = scenarios.sortedByDescending { it.lastUsedAt }.take(3)
        if (recent.isEmpty()) {
            Text(
                stringResource(R.string.no_recent), color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
        } else {
            recent.forEach { sc ->
                AcpCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(sc.name, fontWeight = FontWeight.SemiBold)
                            Text(
                                stringResource(
                                    R.string.scenario_meta, ClickPoint.listFromJson(sc.pointsJson).size,
                                    sc.intervalMs.toInt()
                                ),
                                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp
                            )
                        }
                        FilledTonalButton(onClick = {
                            if (ready) {
                                vm.runScenario(sc, actions)
                            } else if (!rt.a11y) {
                                showDisclosure = true
                            }
                        }) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null)
                            Text(stringResource(R.string.scen_run))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }

    if (showDisclosure) {
        DisclosureDialog(
            onDismiss = { showDisclosure = false },
            onAgree = { showDisclosure = false; actions.openAccessibility() }
        )
    }
}
