package com.autoclickerpro

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalView
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.autoclickerpro.data.ThemeMode
import com.autoclickerpro.service.OverlayService
import com.autoclickerpro.ui.Actions
import com.autoclickerpro.ui.AcpTheme
import com.autoclickerpro.ui.AppRoot
import com.autoclickerpro.ui.MainViewModel

class MainActivity : AppCompatActivity() {
    private val vm: MainViewModel by viewModels()

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshPermissions() }

    private fun panelIntent(action: String? = null) =
        Intent(this, OverlayService::class.java).apply { if (action != null) this.action = action }

    private val actions by lazy {
        Actions(
            openAccessibility = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            openOverlay = {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            },
            requestNotif = {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            },
            launchPanel = {
                ContextCompat.startForegroundService(this, panelIntent())
                Toast.makeText(this, R.string.ev_panel_ready, Toast.LENGTH_LONG).show()
            },
            reloadPanel = { startService(panelIntent(OverlayService.ACTION_RELOAD)) },
            quitPanel = { startService(panelIntent(OverlayService.ACTION_QUIT)) },
            minimize = { moveTaskToBack(true) },
            setLanguage = { l ->
                Lang.set(this, l)
                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(l))
            }
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            val s by vm.settings.collectAsStateWithLifecycle()
            val dark = when (s.theme) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            AcpTheme(dark) {
                val view = LocalView.current
                SideEffect {
                    val c = WindowCompat.getInsetsController(window, view)
                    c.isAppearanceLightStatusBars = !dark
                    c.isAppearanceLightNavigationBars = !dark
                }
                AppRoot(vm, actions)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshPermissions()
    }
}
