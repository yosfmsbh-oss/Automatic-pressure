package com.autoclickerpro

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.autoclickerpro.data.AppDatabase
import com.autoclickerpro.data.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class App : Application() {
    lateinit var repo: SettingsRepository
    lateinit var db: AppDatabase
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        instance = this
        repo = SettingsRepository(this)
        db = AppDatabase.get(this)
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(Lang.get(this)))
    }

    companion object {
        lateinit var instance: App
            private set
    }
}

/** اللغة تُحفظ في SharedPreferences لتُقرأ بشكل متزامن عند إقلاع التطبيق والخدمات. */
object Lang {
    fun get(c: Context): String =
        c.applicationContext.getSharedPreferences("boot", Context.MODE_PRIVATE).getString("lang", "ar") ?: "ar"

    fun set(c: Context, lang: String) {
        c.applicationContext.getSharedPreferences("boot", Context.MODE_PRIVATE)
            .edit().putString("lang", lang).apply()
    }
}
