package com.autoclickerpro.service

import android.content.Context
import android.content.res.Configuration
import com.autoclickerpro.Lang
import java.util.Locale

object LocaleWrap {
    fun wrap(base: Context): Context {
        val locale = Locale(Lang.get(base))
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(locale)
        cfg.setLayoutDirection(locale)
        return base.createConfigurationContext(cfg)
    }
}
