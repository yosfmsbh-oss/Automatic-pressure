package com.autoclickerpro.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF3D7BFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF14264F),
    onPrimaryContainer = Color(0xFFDCE6FF),
    background = Color(0xFF07090D),
    onBackground = Color(0xFFE8ECF4),
    surface = Color(0xFF0E1117),
    onSurface = Color(0xFFE8ECF4),
    surfaceVariant = Color(0xFF14171F),
    onSurfaceVariant = Color(0xFF8A93A6),
    outline = Color(0xFF262C3A),
    error = Color(0xFFFF5C63)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF1F5BFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE6FF),
    onPrimaryContainer = Color(0xFF0B2260),
    background = Color(0xFFF4F6FB),
    onBackground = Color(0xFF10131A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF10131A),
    surfaceVariant = Color(0xFFFFFFFF),
    onSurfaceVariant = Color(0xFF5B6478),
    outline = Color(0xFFDDE2EE),
    error = Color(0xFFD93025)
)

val StatusGreen = Color(0xFF34D399)
val StatusAmber = Color(0xFFFBBF24)
val StatusCyan = Color(0xFF38BDF8)
val StatusGray = Color(0xFF8A93A6)
val StopRed = Color(0xFFE5484D)

@Composable
fun AcpTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        content = content
    )
}
