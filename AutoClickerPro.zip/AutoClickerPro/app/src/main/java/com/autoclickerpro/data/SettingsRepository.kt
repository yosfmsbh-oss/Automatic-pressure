package com.autoclickerpro.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.acpStore by preferencesDataStore(name = "acp_settings")

enum class ThemeMode { DARK, LIGHT, SYSTEM }

data class ClickerSettings(
    val intervalMs: Long = 200L,
    val repeatCount: Int = 0,
    val durationSec: Int = 0,
    val startDelaySec: Int = 0,
    val pointsJson: String = "[]",
    val activeScenarioId: Long = -1L,
    val panelOpacity: Float = 0.92f,
    val panelScale: Float = 1f,
    val panelX: Int = 16,
    val panelY: Int = 220,
    val vibrate: Boolean = true,
    val sound: Boolean = false,
    val sensitiveGuard: Boolean = true,
    val theme: ThemeMode = ThemeMode.DARK,
    val totalClicks: Long = 0L,
    val lastSessionClicks: Long = 0L,
    val lastSessionMs: Long = 0L
)

private object Keys {
    val INTERVAL = longPreferencesKey("interval")
    val REPEAT = intPreferencesKey("repeat")
    val DURATION = intPreferencesKey("duration")
    val DELAY = intPreferencesKey("delay")
    val POINTS = stringPreferencesKey("points")
    val ACTIVE = longPreferencesKey("active")
    val OPACITY = floatPreferencesKey("opacity")
    val SCALE = floatPreferencesKey("scale")
    val PX = intPreferencesKey("px")
    val PY = intPreferencesKey("py")
    val VIBRATE = booleanPreferencesKey("vibrate")
    val SOUND = booleanPreferencesKey("sound")
    val GUARD = booleanPreferencesKey("guard")
    val THEME = stringPreferencesKey("theme")
    val TOTAL = longPreferencesKey("total")
    val LAST = longPreferencesKey("last")
    val LAST_MS = longPreferencesKey("last_ms")
}

/** كل البيانات محلية على الجهاز (DataStore) ولا تُرسل لأي جهة. */
class SettingsRepository(context: Context) {
    private val store = context.applicationContext.acpStore

    val flow: Flow<ClickerSettings> = store.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { read(it) }

    suspend fun update(transform: (ClickerSettings) -> ClickerSettings) {
        store.edit { p -> write(p, transform(read(p))) }
    }

    suspend fun addSession(clicks: Long, ms: Long) {
        update { it.copy(totalClicks = it.totalClicks + clicks, lastSessionClicks = clicks, lastSessionMs = ms) }
    }

    suspend fun resetSettings() {
        update {
            ClickerSettings(
                pointsJson = it.pointsJson,
                totalClicks = it.totalClicks,
                lastSessionClicks = it.lastSessionClicks,
                lastSessionMs = it.lastSessionMs
            )
        }
    }

    private fun read(p: Preferences) = ClickerSettings(
        intervalMs = p[Keys.INTERVAL] ?: 200L,
        repeatCount = p[Keys.REPEAT] ?: 0,
        durationSec = p[Keys.DURATION] ?: 0,
        startDelaySec = p[Keys.DELAY] ?: 0,
        pointsJson = p[Keys.POINTS] ?: "[]",
        activeScenarioId = p[Keys.ACTIVE] ?: -1L,
        panelOpacity = p[Keys.OPACITY] ?: 0.92f,
        panelScale = p[Keys.SCALE] ?: 1f,
        panelX = p[Keys.PX] ?: 16,
        panelY = p[Keys.PY] ?: 220,
        vibrate = p[Keys.VIBRATE] ?: true,
        sound = p[Keys.SOUND] ?: false,
        sensitiveGuard = p[Keys.GUARD] ?: true,
        theme = runCatching { ThemeMode.valueOf(p[Keys.THEME] ?: "DARK") }.getOrDefault(ThemeMode.DARK),
        totalClicks = p[Keys.TOTAL] ?: 0L,
        lastSessionClicks = p[Keys.LAST] ?: 0L,
        lastSessionMs = p[Keys.LAST_MS] ?: 0L
    )

    private fun write(p: MutablePreferences, s: ClickerSettings) {
        p[Keys.INTERVAL] = s.intervalMs
        p[Keys.REPEAT] = s.repeatCount
        p[Keys.DURATION] = s.durationSec
        p[Keys.DELAY] = s.startDelaySec
        p[Keys.POINTS] = s.pointsJson
        p[Keys.ACTIVE] = s.activeScenarioId
        p[Keys.OPACITY] = s.panelOpacity
        p[Keys.SCALE] = s.panelScale
        p[Keys.PX] = s.panelX
        p[Keys.PY] = s.panelY
        p[Keys.VIBRATE] = s.vibrate
        p[Keys.SOUND] = s.sound
        p[Keys.GUARD] = s.sensitiveGuard
        p[Keys.THEME] = s.theme.name
        p[Keys.TOTAL] = s.totalClicks
        p[Keys.LAST] = s.lastSessionClicks
        p[Keys.LAST_MS] = s.lastSessionMs
    }
}
