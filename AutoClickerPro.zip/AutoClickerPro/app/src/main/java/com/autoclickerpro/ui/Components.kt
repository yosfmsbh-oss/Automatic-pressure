package com.autoclickerpro.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.autoclickerpro.R
import com.autoclickerpro.engine.EngineState
import com.autoclickerpro.engine.PanelStatus

/** الإجراءات المرتبطة بالنظام (تُنفَّذ في Activity). */
class Actions(
    val openAccessibility: () -> Unit,
    val openOverlay: () -> Unit,
    val requestNotif: () -> Unit,
    val launchPanel: () -> Unit,
    val reloadPanel: () -> Unit,
    val quitPanel: () -> Unit,
    val minimize: () -> Unit,
    val setLanguage: (String) -> Unit
)

@Composable
fun AcpCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
    )
}

@Composable
fun IntField(
    label: String, value: Long, modifier: Modifier = Modifier,
    maxDigits: Int = 7, onValue: (Long) -> Unit
) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { v ->
            val f = v.filter { it.isDigit() }.take(maxDigits)
            text = f
            f.toLongOrNull()?.let(onValue)
        },
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    )
}

@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun statusColor(st: PanelStatus): Color = when (st) {
    PanelStatus.STOPPED -> StatusGray
    PanelStatus.READY -> StatusCyan
    PanelStatus.RUNNING -> StatusGreen
    PanelStatus.PAUSED -> StatusAmber
}

@Composable
fun statusLabel(st: PanelStatus): String = stringResource(
    when (st) {
        PanelStatus.STOPPED -> R.string.st_stopped
        PanelStatus.READY -> R.string.st_ready
        PanelStatus.RUNNING -> R.string.st_running
        PanelStatus.PAUSED -> R.string.st_paused
    }
)

@Composable
fun StatusChip(st: PanelStatus) {
    val c by animateColorAsState(statusColor(st), label = "chip")
    Surface(shape = CircleShape, color = c.copy(alpha = 0.16f)) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(c))
            Spacer(Modifier.width(8.dp))
            Text(statusLabel(st), color = c, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
    }
}

@Composable
fun PowerButton(status: PanelStatus, engine: EngineState, glyph: String, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val running = engine == EngineState.RUNNING || engine == EngineState.COUNTDOWN
    val target = when {
        running -> StatusGreen
        engine == EngineState.PAUSED -> StatusAmber
        status == PanelStatus.READY -> primary
        else -> StatusGray
    }
    val accent by animateColorAsState(target, label = "power")
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse = transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart),
        label = "p"
    )
    Box(
        Modifier.size(210.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2
            val c = Offset(size.width / 2, size.height / 2)
            if (running) {
                val p = pulse.value
                drawCircle(accent.copy(alpha = 0.30f * (1f - p)), radius = r * (0.62f + 0.38f * p), center = c)
            }
            drawCircle(
                brush = Brush.radialGradient(listOf(accent.copy(alpha = 0.32f), Color.Transparent), c, r),
                radius = r, center = c
            )
            drawCircle(accent.copy(alpha = 0.18f), radius = r * 0.58f, center = c)
            drawCircle(accent.copy(alpha = 0.95f), radius = r * 0.62f, center = c, style = Stroke(5.dp.toPx()))
        }
        Text(glyph, fontSize = 56.sp, color = accent, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PermRow(label: String, granted: Boolean, onEnable: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        if (granted) {
            Text(stringResource(R.string.perm_granted), color = StatusGreen, fontWeight = FontWeight.SemiBold)
        } else {
            Button(onClick = onEnable) { Text(stringResource(R.string.perm_enable)) }
        }
    }
}

@Composable
fun PermissionsCard(
    a11y: Boolean, overlay: Boolean, notif: Boolean, actions: Actions,
    onA11yClick: () -> Unit, modifier: Modifier = Modifier
) {
    AcpCard(modifier.fillMaxWidth()) {
        SectionTitle(stringResource(R.string.perm_title))
        Spacer(Modifier.size(8.dp))
        PermRow(stringResource(R.string.perm_a11y), a11y, onA11yClick)
        PermRow(stringResource(R.string.perm_overlay), overlay, actions.openOverlay)
        PermRow(stringResource(R.string.perm_notif), notif, actions.requestNotif)
    }
}

@Composable
fun DisclosureDialog(onDismiss: () -> Unit, onAgree: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.disc_title)) },
        text = { Text(stringResource(R.string.disc_msg)) },
        confirmButton = { TextButton(onClick = onAgree) { Text(stringResource(R.string.agree)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
fun ConfirmDialog(text: String, confirmLabel: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}
