package com.autoclickerpro.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.autoclickerpro.Lang
import com.autoclickerpro.R
import com.autoclickerpro.data.ThemeMode
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel, actions: Actions, pad: PaddingValues) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    val overlay by vm.overlayGranted.collectAsStateWithLifecycle()
    val notif by vm.notifGranted.collectAsStateWithLifecycle()
    var showDisclosure by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }
    val lang = remember { Lang.get(ctx) }

    var opacity by remember(s.panelOpacity) { mutableFloatStateOf(s.panelOpacity) }
    var scale by remember(s.panelScale) { mutableFloatStateOf(s.panelScale) }

    Column(
        Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            stringResource(R.string.set_title),
            style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold
        )

        PermissionsCard(rt.a11y, overlay, notif, actions, onA11yClick = { showDisclosure = true })

        AcpCard(Modifier.fillMaxWidth()) {
            SectionTitle(stringResource(R.string.set_click))
            Spacer(Modifier.height(10.dp))
            IntField(stringResource(R.string.set_interval), s.intervalMs, Modifier.fillMaxWidth()) { v ->
                vm.update { it.copy(intervalMs = v) }
            }
            Spacer(Modifier.height(8.dp))
            IntField(stringResource(R.string.set_repeat), s.repeatCount.toLong(), Modifier.fillMaxWidth()) { v ->
                vm.update { it.copy(repeatCount = v.toInt()) }
            }
            Spacer(Modifier.height(8.dp))
            IntField(stringResource(R.string.set_duration), s.durationSec.toLong(), Modifier.fillMaxWidth()) { v ->
                vm.update { it.copy(durationSec = v.toInt()) }
            }
            Spacer(Modifier.height(8.dp))
            IntField(stringResource(R.string.set_delay), s.startDelaySec.toLong(), Modifier.fillMaxWidth()) { v ->
                vm.update { it.copy(startDelaySec = v.toInt()) }
            }
        }

        AcpCard(Modifier.fillMaxWidth()) {
            SectionTitle(stringResource(R.string.set_panel))
            Text(stringResource(R.string.set_opacity, (opacity * 100).roundToInt()))
            Slider(
                value = opacity, onValueChange = { opacity = it },
                onValueChangeFinished = { vm.update { it.copy(panelOpacity = opacity) } },
                valueRange = 0.4f..1f
            )
            Text(stringResource(R.string.set_scale, (scale * 100).roundToInt()))
            Slider(
                value = scale, onValueChange = { scale = it },
                onValueChangeFinished = { vm.update { it.copy(panelScale = scale) } },
                valueRange = 0.7f..1.4f
            )
        }

        AcpCard(Modifier.fillMaxWidth()) {
            SectionTitle(stringResource(R.string.set_feedback))
            SwitchRow(stringResource(R.string.set_vibrate), s.vibrate) { v -> vm.update { it.copy(vibrate = v) } }
            SwitchRow(stringResource(R.string.set_sound), s.sound) { v -> vm.update { it.copy(sound = v) } }
            SwitchRow(stringResource(R.string.set_guard), s.sensitiveGuard) { v ->
                vm.update { it.copy(sensitiveGuard = v) }
            }
        }

        AcpCard(Modifier.fillMaxWidth()) {
            SectionTitle(stringResource(R.string.set_appearance))
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    ThemeMode.DARK to R.string.theme_dark,
                    ThemeMode.LIGHT to R.string.theme_light,
                    ThemeMode.SYSTEM to R.string.theme_system
                ).forEach { (m, l) ->
                    FilterChip(
                        selected = s.theme == m,
                        onClick = { vm.update { it.copy(theme = m) } },
                        label = { Text(stringResource(l)) }
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            SectionTitle(stringResource(R.string.set_language))
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = lang == "ar", onClick = { actions.setLanguage("ar") },
                    label = { Text(stringResource(R.string.lang_ar)) }
                )
                FilterChip(
                    selected = lang == "en", onClick = { actions.setLanguage("en") },
                    label = { Text(stringResource(R.string.lang_en)) }
                )
            }
        }

        OutlinedButton(onClick = { showReset = true }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.set_reset))
        }

        AcpCard(Modifier.fillMaxWidth()) {
            SectionTitle(stringResource(R.string.set_about))
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(R.string.privacy_text), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(8.dp))
    }

    if (showDisclosure) {
        DisclosureDialog(
            onDismiss = { showDisclosure = false },
            onAgree = { showDisclosure = false; actions.openAccessibility() }
        )
    }
    if (showReset) {
        ConfirmDialog(
            text = stringResource(R.string.set_reset_q),
            confirmLabel = stringResource(R.string.set_reset),
            onDismiss = { showReset = false },
            onConfirm = { vm.resetSettings(); showReset = false }
        )
    }
}
