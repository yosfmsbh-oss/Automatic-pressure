package com.autoclickerpro.service

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.autoclickerpro.App
import com.autoclickerpro.MainActivity
import com.autoclickerpro.R
import com.autoclickerpro.data.ClickPoint
import com.autoclickerpro.data.ClickerSettings
import com.autoclickerpro.data.Scenario
import com.autoclickerpro.engine.ClickEngine
import com.autoclickerpro.engine.ClickerRuntime
import com.autoclickerpro.engine.EngineConfig
import com.autoclickerpro.engine.EngineEvent
import com.autoclickerpro.engine.EngineState
import com.autoclickerpro.engine.RuntimeState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.min

/**
 * اللوحة العائمة + دوائر نقاط الضغط. لا يبدأ أي ضغط إلا بعد أن يضغط المستخدم ▶ بنفسه
 * (أو يختار سيناريو صراحةً).
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.autoclickerpro.STOP"
        const val ACTION_RELOAD = "com.autoclickerpro.RELOAD"
        const val ACTION_QUIT = "com.autoclickerpro.QUIT"
        private const val CHANNEL = "panel"
        const val MAX_TARGETS = 10

        private const val BLUE = 0xFF2F6BFF.toInt()
        private const val GRAY = 0xFF3A4156.toInt()
        private const val RED = 0xFFE5484D.toInt()
        private const val PANEL_BG = 0xF2111520.toInt()
    }

    private class Target(val view: TextView, val lp: WindowManager.LayoutParams, var delayMs: Long = 0L)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private lateinit var ui: Context
    private val app: App get() = applicationContext as App

    private var cur = ClickerSettings()
    private val targets = mutableListOf<Target>()
    private var root: FrameLayout? = null
    private var rootLp: WindowManager.LayoutParams? = null
    private var fullView: LinearLayout? = null
    private var miniView: TextView? = null
    private var tvCount: TextView? = null
    private var btnPlay: TextView? = null
    private var btnPause: TextView? = null
    private var btnStop: TextView? = null
    private var popup: View? = null
    private var expanded = true
    private var builtScale = -1f
    private var lastTouchable = true

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(LocaleWrap.wrap(base))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        ui = ContextThemeWrapper(this, R.style.Theme_AutoClickerPro)
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        ClickEngine.pointsProvider = { targets.map { it.point() } }
        ClickerRuntime.state.update { it.copy(panelAlive = true) }
        scope.launch {
            cur = app.repo.flow.first()
            buildPanel()
            loadTargets(cur.pointsJson)
            launch {
                app.repo.flow.collect { s ->
                    val scaleChanged = s.panelScale != builtScale
                    cur = s
                    if (scaleChanged) rebuildPanel() else applyOpacity()
                }
            }
            launch { ClickerRuntime.state.collect { render(it) } }
            launch { ClickerRuntime.events.collect { onEvent(it) } }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> ClickEngine.stop()
            ACTION_RELOAD -> scope.launch {
                cur = app.repo.flow.first()
                if (ClickerRuntime.state.value.engine == EngineState.IDLE && root != null) {
                    loadTargets(cur.pointsJson)
                }
            }
            ACTION_QUIT -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        ClickEngine.stop()
        ClickEngine.pointsProvider = null
        savePoints()
        dismissPopup()
        clearTargets()
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        ClickerRuntime.state.update { it.copy(panelAlive = false) }
        scope.cancel()
        super.onDestroy()
    }

    // ---------------- الإشعار (فيه زر الإيقاف الطارئ) ----------------
    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.notif_title), NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        fun action(a: String, req: Int) = PendingIntent.getService(
            this, req, Intent(this, OverlayService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, getString(R.string.notif_stop), action(ACTION_STOP, 1))
            .addAction(0, getString(R.string.notif_close), action(ACTION_QUIT, 2))
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------------- أدوات ----------------
    @Suppress("DEPRECATION")
    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun dp(v: Number): Int = (v.toFloat() * resources.displayMetrics.density).toInt()

    private fun toast(id: Int) = Toast.makeText(this, id, Toast.LENGTH_SHORT).show()

    private fun baseParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, overlayType,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.LEFT
        // إحداثيات النافذة = إحداثيات الشاشة المطلقة حتى مع الشاشات ذات الحواف والنتوءات
        layoutInDisplayCutoutMode =
            if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    private fun screen(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }

    private fun roundBg(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun ovalBg(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun circle(label: String, bg: Int, size: Int, textDp: Float, margin: Int, onClick: () -> Unit) =
        TextView(ui).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, textDp)
            background = ovalBg(bg)
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                leftMargin = margin; rightMargin = margin
            }
            setOnClickListener { onClick() }
        }

    // ---------------- اللوحة ----------------
    private fun buildPanel() {
        val sc = cur.panelScale
        builtScale = sc
        val b = dp(34 * sc)
        val txt = 15f * sc
        val m = dp(2 * sc)

        val handle = circle("≡", 0x00000000, b, txt + 5, m) {}
        val count = TextView(ui).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15f * sc)
            typeface = Typeface.DEFAULT_BOLD
            minWidth = dp(40 * sc)
            text = "0"
        }
        val play = circle("▶", BLUE, b, txt, m) { onPlay() }
        val pause = circle("❚❚", GRAY, b, txt - 4, m) { ClickEngine.pause() }
        val stop = circle("■", RED, b, txt, m) { dismissPopup(); ClickEngine.stop() }
        val add = circle("+", GRAY, b, txt + 4, m) { onAdd() }
        val list = circle("▤", GRAY, b, txt, m) { togglePopup() }
        val minBtn = circle("–", GRAY, b, txt + 2, m) { setExpanded(false) }
        val close = circle("✕", GRAY, b, txt - 2, m) { stopSelf() }

        val full = LinearLayout(ui).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundBg(PANEL_BG, dp(26 * sc), BLUE)
            setPadding(dp(4 * sc), dp(5 * sc), dp(6 * sc), dp(5 * sc))
            listOf(handle, count, play, pause, stop, add, list, minBtn, close).forEach { addView(it) }
        }
        val mini = TextView(ui).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14f * sc)
            typeface = Typeface.DEFAULT_BOLD
            background = ovalBg(BLUE)
            text = "0"
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(dp(46 * sc), dp(46 * sc))
        }
        val r = FrameLayout(ui).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(full)
            addView(mini)
        }
        val lp = rootLp ?: baseParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT
        ).apply { x = cur.panelX; y = cur.panelY }
        lp.alpha = cur.panelOpacity
        rootLp = lp

        attachDrag(handle, r, lp, null) { savePanelPos() }
        attachDrag(mini, r, lp, { setExpanded(true) }) { savePanelPos() }

        tvCount = count; btnPlay = play; btnPause = pause; btnStop = stop
        fullView = full; miniView = mini; root = r
        full.visibility = if (expanded) View.VISIBLE else View.GONE
        mini.visibility = if (expanded) View.GONE else View.VISIBLE
        wm.addView(r, lp)
        render(ClickerRuntime.state.value)
    }

    private fun rebuildPanel() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        buildPanel()
    }

    private fun applyOpacity() {
        val lp = rootLp ?: return
        val r = root ?: return
        lp.alpha = cur.panelOpacity
        try { wm.updateViewLayout(r, lp) } catch (_: Exception) {}
    }

    private fun setExpanded(e: Boolean) {
        expanded = e
        fullView?.visibility = if (e) View.VISIBLE else View.GONE
        miniView?.visibility = if (e) View.GONE else View.VISIBLE
        dismissPopup()
        val lp = rootLp ?: return
        val r = root ?: return
        try { wm.updateViewLayout(r, lp) } catch (_: Exception) {}
    }

    private fun savePanelPos() {
        val lp = rootLp ?: return
        val x = lp.x
        val y = lp.y
        app.appScope.launch { app.repo.update { it.copy(panelX = x, panelY = y) } }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachDrag(
        handle: View, rootView: View, lp: WindowManager.LayoutParams,
        onTap: (() -> Unit)?, onEnd: () -> Unit
    ) {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        val slop = ViewConfiguration.get(ui).scaledTouchSlop
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) {
                        moved = true
                        dismissPopup()
                    }
                    if (moved) {
                        lp.x = (sx + dx).toInt()
                        lp.y = (sy + dy).toInt()
                        try { wm.updateViewLayout(rootView, lp) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (moved) onEnd() else onTap?.invoke()
            }
            true
        }
    }

    // ---------------- أزرار اللوحة ----------------
    private fun onPlay() {
        when (ClickerRuntime.state.value.engine) {
            EngineState.PAUSED -> ClickEngine.resume()
            EngineState.IDLE -> {
                dismissPopup()
                savePoints()
                ClickEngine.start(EngineConfig.from(cur))
            }
            else -> {}
        }
    }

    private fun onAdd() {
        val e = ClickerRuntime.state.value.engine
        if (e == EngineState.IDLE || e == EngineState.PAUSED) addTarget(null, null)
    }

    private fun render(st: RuntimeState) {
        val active = st.engine == EngineState.RUNNING || st.engine == EngineState.COUNTDOWN
        val label = if (st.countdown > 0) "⏳${st.countdown}" else st.clicks.toString()
        tvCount?.text = label
        miniView?.text = label
        btnPlay?.alpha = if (st.engine == EngineState.IDLE || st.engine == EngineState.PAUSED) 1f else 0.35f
        btnPause?.alpha = if (st.engine == EngineState.RUNNING) 1f else 0.35f
        btnStop?.alpha = if (st.engine == EngineState.IDLE) 0.45f else 1f
        val touchable = !active
        if (touchable != lastTouchable) {
            lastTouchable = touchable
            targets.forEach { setTouchable(it, touchable) }
        }
        if (active) dismissPopup()
    }

    private fun onEvent(e: EngineEvent) {
        when (e) {
            EngineEvent.GUARD_PAUSED -> toast(R.string.ev_guard)
            EngineEvent.A11Y_LOST -> toast(R.string.ev_a11y)
            EngineEvent.NO_POINTS -> toast(R.string.ev_nopoints)
            EngineEvent.TAP_FAILED -> toast(R.string.ev_tapfail)
            EngineEvent.FINISHED ->
                Toast.makeText(
                    this, getString(R.string.ev_finished, ClickerRuntime.state.value.clicks), Toast.LENGTH_SHORT
                ).show()
        }
    }

    // ---------------- نافذة السيناريوهات ----------------
    private fun togglePopup() {
        if (popup != null) {
            dismissPopup(); return
        }
        scope.launch { showPopup(app.db.scenarios().getAll()) }
    }

    private fun dismissPopup() {
        popup?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        popup = null
    }

    private fun showPopup(list: List<Scenario>) {
        val rl = rootLp ?: return
        val rv = root ?: return
        val col = LinearLayout(ui).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(PANEL_BG, dp(16), BLUE)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        fun row(text: String, click: (() -> Unit)?) = TextView(ui).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15f)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44))
            if (click != null) setOnClickListener { click() }
        }
        if (list.isEmpty()) col.addView(row(getString(R.string.panel_no_scn), null))
        list.forEach { s -> col.addView(row("▶  ${s.name}") { dismissPopup(); runScenario(s) }) }
        val sv = ScrollView(ui).apply { addView(col) }
        val h = min(maxOf(list.size, 1) * dp(44) + dp(12), dp(264))
        val (_, sh) = screen()
        val below = rl.y + (rv.height.takeIf { it > 0 } ?: dp(52)) + dp(6)
        val lp = baseParams(dp(240), h).apply {
            x = rl.x.coerceAtLeast(0)
            y = if (below + h <= sh) below else (rl.y - h - dp(6)).coerceAtLeast(0)
        }
        wm.addView(sv, lp)
        popup = sv
    }

    private fun runScenario(s: Scenario) {
        scope.launch {
            ClickEngine.stop()
            app.repo.update {
                it.copy(
                    intervalMs = s.intervalMs, repeatCount = s.repeatCount, durationSec = s.durationSec,
                    startDelaySec = s.startDelaySec, pointsJson = s.pointsJson, activeScenarioId = s.id
                )
            }
            app.db.scenarios().touch(s.id, System.currentTimeMillis())
            val fresh = app.repo.flow.first()
            cur = fresh
            loadTargets(fresh.pointsJson)
            delay(300)
            ClickEngine.start(EngineConfig.from(fresh))
        }
    }

    // ---------------- دوائر النقاط ----------------
    private fun Target.point(): ClickPoint {
        val half = dp(52) / 2
        return ClickPoint(lp.x + half, lp.y + half, delayMs)
    }

    private fun addTarget(cx: Int?, cy: Int?, delayMs: Long = 0L, save: Boolean = true) {
        if (targets.size >= MAX_TARGETS) {
            toast(R.string.max_points); return
        }
        val size = dp(52)
        val half = size / 2
        val (sw, sh) = screen()
        val n = targets.size
        val tv = TextView(ui).apply {
            text = (n + 1).toString()
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC2F6BFF.toInt())
                setStroke(dp(3), Color.WHITE)
            }
        }
        val lp = baseParams(size, size).apply {
            x = ((cx ?: (sw / 2 + n * dp(58))) - half).coerceIn(0, (sw - size).coerceAtLeast(0))
            y = ((cy ?: (sh / 2)) - half).coerceIn(0, (sh - size).coerceAtLeast(0))
            alpha = 0.8f
            if (!lastTouchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        attachDrag(tv, tv, lp, null) { savePoints() }
        wm.addView(tv, lp)
        targets.add(Target(tv, lp, delayMs))
        if (save) savePoints()
    }

    private fun clearTargets() {
        targets.forEach { try { wm.removeView(it.view) } catch (_: Exception) {} }
        targets.clear()
    }

    private fun loadTargets(json: String) {
        clearTargets()
        ClickPoint.listFromJson(json).take(MAX_TARGETS).forEach { addTarget(it.x, it.y, it.delayMs, false) }
        if (targets.isEmpty()) addTarget(null, null, 0L, false)
        savePoints()
    }

    private fun savePoints() {
        if (targets.isEmpty()) return
        val json = ClickPoint.listToJson(targets.map { it.point() })
        cur = cur.copy(pointsJson = json)
        app.appScope.launch { app.repo.update { it.copy(pointsJson = json) } }
    }

    private fun setTouchable(t: Target, touchable: Boolean) {
        val f = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        t.lp.flags = if (touchable) t.lp.flags and f.inv() else t.lp.flags or f
        t.lp.alpha = if (touchable) 0.8f else 0.4f
        try { wm.updateViewLayout(t.view, t.lp) } catch (_: Exception) {}
    }
}
