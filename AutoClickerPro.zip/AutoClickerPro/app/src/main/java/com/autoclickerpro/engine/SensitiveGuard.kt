package com.autoclickerpro.engine

/**
 * حماية تعتمد على اسم حزمة التطبيق المفتوح فقط (دون قراءة محتوى الشاشة).
 * هي قاعدة تقريبية: لا تكشف صفحة دفع داخل تطبيق عادي.
 */
object SensitiveGuard {
    private val exact = setOf(
        "com.google.android.apps.walletnfcrel",
        "com.google.android.apps.nbu.paisa.user",
        "com.paypal.android.p2pmobile",
        "com.samsung.android.spay",
        "com.android.vending",
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller"
    )
    private val fragments = listOf("bank", "wallet", "paypal")

    fun isBlocked(pkg: String?): Boolean {
        if (pkg == null) return false
        val p = pkg.lowercase()
        return p in exact || fragments.any { p.contains(it) }
    }
}
