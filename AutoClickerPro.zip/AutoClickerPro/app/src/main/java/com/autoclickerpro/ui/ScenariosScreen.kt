package com.autoclickerpro.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.autoclickerpro.R
import com.autoclickerpro.data.ClickPoint
import com.autoclickerpro.data.Scenario

@Composable
fun ScenariosScreen(vm: MainViewModel, actions: Actions, pad: PaddingValues) {
    val list by vm.scenarios.collectAsStateWithLifecycle()
    val s by vm.settings.collectAsStateWithLifecycle()
    val rt by vm.runtime.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<Scenario?>(null) }
    var deleting by remember { mutableStateOf<Scenario?>(null) }
    val copySuffix = stringResource(R.string.scen_copy_suffix)
    BackHandler(enabled = editing != null) { editing = null }

    AnimatedContent(targetState = editing, label = "scn") { ed ->
        if (ed == null) {
            Column(
                Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.scen_title), Modifier.weight(1f),
                        style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold
                    )
                    Button(onClick = {
                        editing = Scenario(
                            name = "", pointsJson = s.pointsJson, intervalMs = s.intervalMs,
                            repeatCount = s.repeatCount, durationSec = s.durationSec,
                            startDelaySec = s.startDelaySec, createdAt = System.currentTimeMillis()
                        )
                    }) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Text(stringResource(R.string.scen_new))
                    }
                }
                Text(
                    stringResource(R.string.ed_hint), color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
                if (list.isEmpty()) {
                    Text(
                        stringResource(R.string.scen_empty), Modifier.padding(top = 24.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                list.forEach { sc ->
                    AcpCard(Modifier.fillMaxWidth()) {
                        Text(sc.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(
                            stringResource(
                                R.string.scenario_meta, ClickPoint.listFromJson(sc.pointsJson).size, sc.intervalMs.toInt()
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FilledTonalButton(
                                onClick = { vm.runScenario(sc, actions) },
                                enabled = rt.a11y
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                                Text(stringResource(R.string.scen_run))
                            }
                            IconButton(onClick = { editing = sc }) {
                                Icon(Icons.Filled.Edit, contentDescription = stringResource(R.string.ed_save))
                            }
                            TextButton(onClick = { vm.duplicateScenario(sc, copySuffix) }) {
                                Text(stringResource(R.string.scen_dup))
                            }
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { deleting = sc }) {
                                Icon(
                                    Icons.Filled.Delete, contentDescription = stringResource(R.string.scen_delete),
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        } else {
            ScenarioEditor(ed, vm, actions, pad, onClose = { editing = null })
        }
    }

    deleting?.let { d ->
        ConfirmDialog(
            text = stringResource(R.string.scen_delete_q, d.name),
            confirmLabel = stringResource(R.string.scen_delete),
            onDismiss = { deleting = null },
            onConfirm = { vm.deleteScenario(d); deleting = null }
        )
    }
}

@Composable
private fun ScenarioEditor(initial: Scenario, vm: MainViewModel, actions: Actions, pad: PaddingValues, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(initial.name) }
    var interval by remember { mutableStateOf(initial.intervalMs) }
    var repeat by remember { mutableStateOf(initial.repeatCount.toLong()) }
    var duration by remember { mutableStateOf(initial.durationSec.toLong()) }
    var delay by remember { mutableStateOf(initial.startDelaySec.toLong()) }
    val pts = remember { mutableStateListOf<ClickPoint>().apply { addAll(initial.parsePoints()) } }
    val needName = stringResource(R.string.ed_need_name)
    val needPoints = stringResource(R.string.ed_need_points)
    val loadedMsg = stringResource(R.string.ed_loaded)

    fun build() = initial.copy(
        name = name.trim(), pointsJson = ClickPoint.listToJson(pts.toList()),
        intervalMs = interval, repeatCount = repeat.toInt(), durationSec = duration.toInt(),
        startDelaySec = delay.toInt()
    )

    Column(
        Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onClose) { Text(stringResource(R.string.cancel)) }
            Spacer(Modifier.weight(1f))
            Button(onClick = {
                when {
                    name.isBlank() -> Toast.makeText(ctx, needName, Toast.LENGTH_SHORT).show()
                    pts.isEmpty() -> Toast.makeText(ctx, needPoints, Toast.LENGTH_SHORT).show()
                    else -> { vm.saveScenario(build()); onClose() }
                }
            }) { Text(stringResource(R.string.ed_save)) }
        }
        OutlinedTextField(
            value = name, onValueChange = { name = it.take(40) },
            label = { Text(stringResource(R.string.ed_name)) }, singleLine = true,
            shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
        )
        IntField(stringResource(R.string.ed_interval), interval, Modifier.fillMaxWidth()) { interval = it }
        IntField(stringResource(R.string.ed_repeat), repeat, Modifier.fillMaxWidth()) { repeat = it }
        IntField(stringResource(R.string.ed_duration), duration, Modifier.fillMaxWidth()) { duration = it }
        IntField(stringResource(R.string.ed_delay), delay, Modifier.fillMaxWidth()) { delay = it }

        SectionTitle(stringResource(R.string.ed_points))
        pts.forEachIndexed { i, p ->
            AcpCard(Modifier.fillMaxWidth()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${i + 1}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    IntField("X", p.x.toLong(), Modifier.weight(1f), 5) { pts[i] = pts[i].copy(x = it.toInt()) }
                    IntField("Y", p.y.toLong(), Modifier.weight(1f), 5) { pts[i] = pts[i].copy(y = it.toInt()) }
                    IntField(stringResource(R.string.ed_pdelay), p.delayMs, Modifier.weight(1.3f), 6) {
                        pts[i] = pts[i].copy(delayMs = it)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        if (i > 0) { val t = pts[i]; pts[i] = pts[i - 1]; pts[i - 1] = t }
                    }) { Text("▲") }
                    TextButton(onClick = {
                        if (i < pts.size - 1) { val t = pts[i]; pts[i] = pts[i + 1]; pts[i + 1] = t }
                    }) { Text("▼") }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { pts.removeAt(i) }) {
                        Icon(Icons.Filled.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
        OutlinedButton(
            onClick = { if (pts.size < 10) pts.add(ClickPoint(540, 1200 + pts.size * 10)) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Text(stringResource(R.string.ed_add_point))
        }
        FilledTonalButton(
            onClick = {
                if (pts.isEmpty()) {
                    Toast.makeText(ctx, needPoints, Toast.LENGTH_SHORT).show()
                } else {
                    vm.loadScenario(build().copy(name = name.ifBlank { "-" }), actions)
                    Toast.makeText(ctx, loadedMsg, Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(stringResource(R.string.ed_load_panel)) }
        Spacer(Modifier.height(8.dp))
    }
}
