package com.autoclickerpro.engine

import com.autoclickerpro.data.ClickerSettings
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow

enum class EngineState { IDLE, COUNTDOWN, RUNNING, PAUSED }
enum class PanelStatus { STOPPED, READY, RUNNING, PAUSED }
enum class EngineEvent { GUARD_PAUSED, A11Y_LOST, NO_POINTS, FINISHED, TAP_FAILED }

data class RuntimeState(
    val panelAlive: Boolean = false,
    val a11y: Boolean = false,
    val engine: EngineState = EngineState.IDLE,
    val clicks: Long = 0L,
    val elapsedMs: Long = 0L,
    val countdown: Int = 0
) {
    val status: PanelStatus
        get() = when {
            !panelAlive -> PanelStatus.STOPPED
            engine == EngineState.IDLE -> PanelStatus.READY
            engine == EngineState.PAUSED -> PanelStatus.PAUSED
            else -> PanelStatus.RUNNING
        }
}

/** الحالة الحية المشتركة بين الواجهة واللوحة العائمة والمحرك. */
object ClickerRuntime {
    val state = MutableStateFlow(RuntimeState())
    val events = MutableSharedFlow<EngineEvent>(extraBufferCapacity = 8)
}

data class EngineConfig(
    val intervalMs: Long,
    val repeatCount: Int,
    val durationSec: Int,
    val startDelaySec: Int,
    val vibrate: Boolean,
    val sound: Boolean,
    val guard: Boolean
) {
    companion object {
        fun from(s: ClickerSettings, minDelaySec: Int = 0) = EngineConfig(
            intervalMs = EngineMath.clampInterval(s.intervalMs),
            repeatCount = s.repeatCount,
            durationSec = s.durationSec,
            startDelaySec = maxOf(s.startDelaySec, minDelaySec),
            vibrate = s.vibrate,
            sound = s.sound,
            guard = s.sensitiveGuard
        )
    }
}
