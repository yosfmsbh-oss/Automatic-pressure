package com.autoclickerpro.engine

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import com.autoclickerpro.App

object Feedback {
    fun pulse(vibrate: Boolean, sound: Boolean) {
        val ctx = App.instance
        if (vibrate) {
            try {
                ctx.getSystemService(Vibrator::class.java)
                    ?.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
            } catch (_: Exception) {
            }
        }
        if (sound) {
            try {
                val t = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 50)
                t.startTone(ToneGenerator.TONE_PROP_BEEP, 90)
                Handler(Looper.getMainLooper()).postDelayed({ t.release() }, 400)
            } catch (_: Exception) {
            }
        }
    }
}
