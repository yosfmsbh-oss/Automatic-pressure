package com.autoclickerpro

import com.autoclickerpro.data.ClickPoint
import com.autoclickerpro.engine.EngineMath
import com.autoclickerpro.engine.SensitiveGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LogicTest {
    @Test fun intervalIsClampedToMinimum() {
        assertEquals(10L, EngineMath.clampInterval(1))
        assertEquals(500L, EngineMath.clampInterval(500))
    }

    @Test fun cpsMatchesInterval() {
        assertEquals(5.0, EngineMath.cps(200), 0.001)
        assertEquals(100.0, EngineMath.cps(1), 0.001) // يُقرَّب للحد الأدنى 10ms
    }

    @Test fun tapDurationAndRestSumToInterval() {
        for (i in listOf(10L, 50L, 200L, 1000L, 60000L)) {
            assertEquals(EngineMath.clampInterval(i), EngineMath.tapDurationMs(i) + EngineMath.restAfterTap(i))
        }
        assertEquals(40L, EngineMath.tapDurationMs(1000))
    }

    @Test fun durationFormatting() {
        assertEquals("00:00", EngineMath.formatDuration(0))
        assertEquals("01:05", EngineMath.formatDuration(65_000))
        assertEquals("1:00:01", EngineMath.formatDuration(3_601_000))
    }

    @Test fun pointsRoundTripPreservesOrderAndDelay() {
        val pts = listOf(ClickPoint(10, 20, 0), ClickPoint(300, 400, 750), ClickPoint(5, 6, 1))
        assertEquals(pts, ClickPoint.listFromJson(ClickPoint.listToJson(pts)))
    }

    @Test fun badJsonGivesEmptyList() {
        assertTrue(ClickPoint.listFromJson("not json").isEmpty())
        assertTrue(ClickPoint.listFromJson(null).isEmpty())
        assertTrue(ClickPoint.listFromJson("[]").isEmpty())
    }

    @Test fun guardBlocksSensitivePackages() {
        assertTrue(SensitiveGuard.isBlocked("com.mybank.mobile"))
        assertTrue(SensitiveGuard.isBlocked("com.paypal.android.p2pmobile"))
        assertTrue(SensitiveGuard.isBlocked("com.android.vending"))
        assertFalse(SensitiveGuard.isBlocked("com.example.game"))
        assertFalse(SensitiveGuard.isBlocked(null))
    }
}
