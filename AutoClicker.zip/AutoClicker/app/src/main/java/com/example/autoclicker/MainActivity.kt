package com.example.autoclicker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.core.widget.doAfterTextChanged
import com.example.autoclicker.databinding.ActivityMainBinding
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        loadFields()

        b.etInterval.doAfterTextChanged { updateCps() }
        b.btnSlow.setOnClickListener { b.etInterval.setText("1000") }
        b.btnMid.setOnClickListener { b.etInterval.setText("200") }
        b.btnFast.setOnClickListener { b.etInterval.setText("50") }

        b.btnStart.setOnClickListener { togglePanel() }
        b.btnAccess.setOnClickListener { showDisclosure() }
        b.btnOverlay.setOnClickListener { openOverlaySettings() }
        b.btnSave.setOnClickListener { saveProfileDialog() }
        b.btnLoad.setOnClickListener { loadProfileDialog() }
        b.btnResetLog.setOnClickListener {
            prefs.totalClicks = 0; prefs.lastSession = 0; refreshStatus()
        }
        b.btnLang.setOnClickListener { toggleLang() }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onPause() {
        saveFields()
        super.onPause()
    }

    private fun loadFields() {
        b.etInterval.setText(prefs.intervalMs.toString())
        b.etCount.setText(prefs.maxClicks.toString())
        b.etDelay.setText(prefs.startDelaySec.toString())
        b.etStopAfter.setText(prefs.stopAfterSec.toString())
        updateCps()
    }

    private fun saveFields() {
        prefs.intervalMs = b.etInterval.text.toString().toLongOrNull() ?: 200L
        prefs.maxClicks = b.etCount.text.toString().toIntOrNull() ?: 0
        prefs.startDelaySec = b.etDelay.text.toString().toIntOrNull() ?: 0
        prefs.stopAfterSec = b.etStopAfter.text.toString().toIntOrNull() ?: 0
    }

    private fun updateCps() {
        val ms = (b.etInterval.text.toString().toLongOrNull() ?: 200L).coerceAtLeast(10L)
        b.tvCps.text = getString(R.string.cps_fmt, String.format(Locale.US, "%.1f", 1000.0 / ms))
    }

    private fun refreshStatus() {
        val a11y = ClickerAccessibilityService.instance != null
        val overlay = Settings.canDrawOverlays(this)
        b.tvAccess.setText(if (a11y) R.string.a11y_on else R.string.a11y_off)
        b.tvAccess.setTextColor(ContextCompat.getColor(this, if (a11y) R.color.ok else R.color.bad))
        b.btnAccess.visibility = if (a11y) android.view.View.GONE else android.view.View.VISIBLE
        b.tvOverlay.setText(if (overlay) R.string.overlay_on else R.string.overlay_off)
        b.tvOverlay.setTextColor(ContextCompat.getColor(this, if (overlay) R.color.ok else R.color.bad))
        b.btnOverlay.visibility = if (overlay) android.view.View.GONE else android.view.View.VISIBLE
        b.btnStart.setText(if (OverlayService.alive) R.string.stop_panel else R.string.start_panel)
        b.tvStats.text = getString(R.string.log_fmt, prefs.lastSession, prefs.totalClicks)
        b.btnLang.setText(R.string.lang_switch)
    }

    private fun togglePanel() {
        saveFields()
        if (OverlayService.alive) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_QUIT))
            b.root.postDelayed({ refreshStatus() }, 400)
            return
        }
        if (!Settings.canDrawOverlays(this)) { openOverlaySettings(); return }
        if (ClickerAccessibilityService.instance == null) {
            Toast.makeText(this, R.string.need_a11y, Toast.LENGTH_LONG).show()
            showDisclosure()
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        moveTaskToBack(true)
    }

    private fun openOverlaySettings() {
        Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show()
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    /** إفصاح واضح قبل إرسال المستخدم إلى إعدادات إمكانية الوصول. */
    private fun showDisclosure() {
        AlertDialog.Builder(this)
            .setTitle(R.string.disclosure_title)
            .setMessage(R.string.disclosure_msg)
            .setPositiveButton(R.string.agree) { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun saveProfileDialog() {
        saveFields()
        val input = EditText(this).apply { setHint(R.string.profile_name_hint) }
        val box = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0); addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.save_profile)
            .setView(box)
            .setPositiveButton(R.string.save) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    prefs.saveProfile(name)
                    Toast.makeText(this, R.string.saved_ok, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun loadProfileDialog() {
        val names = prefs.profileNames()
        if (names.isEmpty()) {
            Toast.makeText(this, R.string.no_profiles, Toast.LENGTH_SHORT).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.load_profile)
            .setItems(names.toTypedArray()) { _, i ->
                if (prefs.loadProfile(names[i])) {
                    loadFields()
                    if (OverlayService.alive) {
                        startService(
                            Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_RELOAD)
                        )
                    }
                    Toast.makeText(this, R.string.profile_loaded, Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun toggleLang() {
        saveFields()
        prefs.lang = if (prefs.lang == "ar") "en" else "ar"
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(prefs.lang))
    }
}
