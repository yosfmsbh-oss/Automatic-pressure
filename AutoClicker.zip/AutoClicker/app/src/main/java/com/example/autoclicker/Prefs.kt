package com.example.autoclicker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** كل البيانات تُحفظ محليًا على الجهاز فقط. */
class Prefs(context: Context) {
    private val sp = (context.applicationContext ?: context)
        .getSharedPreferences("settings", Context.MODE_PRIVATE)

    var intervalMs: Long
        get() = sp.getLong("interval", 200L)
        set(v) = sp.edit().putLong("interval", v.coerceIn(10L, 600_000L)).apply()

    /** 0 = مستمر حتى الإيقاف */
    var maxClicks: Int
        get() = sp.getInt("max", 0)
        set(v) = sp.edit().putInt("max", v.coerceAtLeast(0)).apply()

    var startDelaySec: Int
        get() = sp.getInt("delay", 0)
        set(v) = sp.edit().putInt("delay", v.coerceAtLeast(0)).apply()

    /** 0 = بدون إيقاف زمني */
    var stopAfterSec: Int
        get() = sp.getInt("stop", 0)
        set(v) = sp.edit().putInt("stop", v.coerceAtLeast(0)).apply()

    var lang: String
        get() = sp.getString("lang", "ar") ?: "ar"
        set(v) = sp.edit().putString("lang", v).apply()

    var totalClicks: Long
        get() = sp.getLong("total", 0L)
        set(v) = sp.edit().putLong("total", v).apply()

    var lastSession: Long
        get() = sp.getLong("last", 0L)
        set(v) = sp.edit().putLong("last", v).apply()

    /** مواضع النقاط: [[x,y],[x,y],...] */
    var points: String
        get() = sp.getString("points", "[]") ?: "[]"
        set(v) = sp.edit().putString("points", v).apply()

    private fun profiles() = JSONObject(sp.getString("profiles", "{}") ?: "{}")

    fun profileNames(): List<String> = profiles().keys().asSequence().toList().sorted()

    fun saveProfile(name: String) {
        val o = profiles()
        o.put(
            name, JSONObject()
                .put("interval", intervalMs).put("max", maxClicks)
                .put("delay", startDelaySec).put("stop", stopAfterSec)
                .put("points", JSONArray(points))
        )
        sp.edit().putString("profiles", o.toString()).apply()
    }

    fun loadProfile(name: String): Boolean {
        val j = profiles().optJSONObject(name) ?: return false
        intervalMs = j.optLong("interval", 200L)
        maxClicks = j.optInt("max", 0)
        startDelaySec = j.optInt("delay", 0)
        stopAfterSec = j.optInt("stop", 0)
        points = j.optJSONArray("points")?.toString() ?: "[]"
        return true
    }
}
