package com.example.autoclicker

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object LocaleHelper {
    /** يجعل الخدمات (اللوحة العائمة) تتبع لغة التطبيق المختارة. */
    fun wrap(base: Context): Context {
        val locale = Locale(Prefs(base).lang)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(locale)
        cfg.setLayoutDirection(locale)
        return base.createConfigurationContext(cfg)
    }
}
