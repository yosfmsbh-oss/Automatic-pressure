package com.example.autoclicker

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import org.json.JSONArray

/**
 * اللوحة العائمة + نقاط الضغط + محرك الضغط.
 * لا يبدأ أي ضغط إلا بعد أن يضغط المستخدم زر التشغيل في اللوحة بنفسه.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP_CLICKING = "com.example.autoclicker.STOP_CLICKING"
        const val ACTION_RELOAD = "com.example.autoclicker.RELOAD"
        const val ACTION_QUIT = "com.example.autoclicker.QUIT"
        private const val CHANNEL = "panel"
        private const val MAX_TARGETS = 10

        @Volatile
        var alive = false
    }

    private class Target(val view: TextView, val lp: WindowManager.LayoutParams)

    @Suppress("DEPRECATION")
    private val overlayType =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var ui: Context
    private val handler = Handler(Looper.getMainLooper())
    private val targets = mutableListOf<Target>()
    private var panel: View? = null
    private var btnPlay: TextView? = null
    private var tvCount: TextView? = null

    private var clicking = false
    private var session = 0L
    private var cursor = 0
    private var clickStart = 0L
    private var maxClicks = 0
    private var stopAfterMs = 0L

    override fun attachBaseContext(base: Context) = super.attachBaseContext(LocaleHelper.wrap(base))
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        alive = true
        prefs = Prefs(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        ui = ContextThemeWrapper(this, R.style.Theme_AutoClicker)
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        buildPanel()
        loadTargets()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_CLICKING -> stopClicking()
            ACTION_RELOAD -> if (!clicking && panel != null) loadTargets()
            ACTION_QUIT -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopClicking()
        savePoints()
        clearTargets()
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        handler.removeCallbacksAndMessages(null)
        alive = false
        super.onDestroy()
    }

    // ---------------- إشعار الخدمة (يحتوي زر الإيقاف الطارئ) ----------------
    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, getString(R.string.notif_title), NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        fun action(a: String, req: Int) = PendingIntent.getService(
            this, req, Intent(this, OverlayService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, getString(R.string.notif_stop), action(ACTION_STOP_CLICKING, 1))
            .addAction(0, getString(R.string.notif_close), action(ACTION_QUIT, 2))
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------------- النوافذ العائمة ----------------
    private fun baseParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, overlayType,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.LEFT }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(id: Int) = Toast.makeText(this, id, Toast.LENGTH_SHORT).show()

    private fun buildPanel() {
        val v = LayoutInflater.from(ui).inflate(R.layout.overlay_panel, null)
        val lp = baseParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
            .apply { x = dp(8); y = dp(120) }
        btnPlay = v.findViewById(R.id.btnPlay)
        tvCount = v.findViewById(R.id.tvCount)
        btnPlay?.setOnClickListener { if (clicking) stopClicking() else startClicking() }
        v.findViewById<View>(R.id.btnAdd).setOnClickListener { if (!clicking) addTarget() }
        v.findViewById<View>(R.id.btnRemove).setOnClickListener { if (!clicking) removeTarget() }
        v.findViewById<View>(R.id.btnSettings).setOnClickListener { openMain() }
        v.findViewById<View>(R.id.btnClose).setOnClickListener { stopSelf() }
        attachDrag(v.findViewById(R.id.handle), v, lp, false)
        wm.addView(v, lp)
        panel = v
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachDrag(handle: View, root: View, lp: WindowManager.LayoutParams, persist: Boolean) {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (sx + e.rawX - tx).toInt()
                    lp.y = (sy + e.rawY - ty).toInt()
                    wm.updateViewLayout(root, lp)
                }
                MotionEvent.ACTION_UP -> if (persist) savePoints()
            }
            true
        }
    }

    private fun addTarget(px: Int? = null, py: Int? = null) {
        if (targets.size >= MAX_TARGETS) { toast(R.string.max_targets); return }
        val size = dp(52)
        val dm = resources.displayMetrics
        val n = targets.size
        val tv = TextView(ui).apply {
            text = (n + 1).toString()
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setBackgroundResource(R.drawable.target_bg)
        }
        val lp = baseParams(size, size).apply {
            x = (px ?: (dm.widthPixels / 2 - size / 2 + n * dp(60))).coerceIn(0, dm.widthPixels - size)
            y = (py ?: (dm.heightPixels / 2 - size / 2)).coerceIn(0, dm.heightPixels - size)
            alpha = 0.8f
        }
        attachDrag(tv, tv, lp, true)
        wm.addView(tv, lp)
        targets.add(Target(tv, lp))
        savePoints()
    }

    private fun removeTarget() {
        if (targets.size <= 1) return
        val t = targets.removeAt(targets.size - 1)
        try { wm.removeView(t.view) } catch (_: Exception) {}
        savePoints()
    }

    private fun clearTargets() {
        targets.forEach { try { wm.removeView(it.view) } catch (_: Exception) {} }
        targets.clear()
    }

    private fun loadTargets() {
        clearTargets()
        val arr = try { JSONArray(prefs.points) } catch (_: Exception) { JSONArray() }
        for (i in 0 until minOf(arr.length(), MAX_TARGETS)) {
            val p = arr.optJSONArray(i) ?: continue
            addTarget(p.optInt(0), p.optInt(1))
        }
        if (targets.isEmpty()) addTarget()
    }

    private fun savePoints() {
        if (targets.isEmpty()) return
        val arr = JSONArray()
        targets.forEach { arr.put(JSONArray().put(it.lp.x).put(it.lp.y)) }
        prefs.points = arr.toString()
    }

    private fun setTouchable(t: Target, touchable: Boolean) {
        val f = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        t.lp.flags = if (touchable) t.lp.flags and f.inv() else t.lp.flags or f
        t.lp.alpha = if (touchable) 0.8f else 0.4f
        try { wm.updateViewLayout(t.view, t.lp) } catch (_: Exception) {}
    }

    private fun center(t: Target): Pair<Float, Float> {
        val loc = IntArray(2)
        t.view.getLocationOnScreen(loc)
        val w = if (t.view.width > 0) t.view.width else dp(52)
        return Pair(loc[0] + w / 2f, loc[1] + w / 2f)
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun refreshPanel() {
        btnPlay?.text = if (clicking) "■" else "▶"
        btnPlay?.setBackgroundResource(if (clicking) R.drawable.btn_stop_bg else R.drawable.btn_play_bg)
    }

    // ---------------- محرك الضغط ----------------
    private fun startClicking() {
        if (clicking) return
        if (ClickerAccessibilityService.instance == null) {
            toast(R.string.need_a11y)
            openMain()
            return
        }
        clicking = true
        session = 0
        cursor = 0
        maxClicks = prefs.maxClicks
        stopAfterMs = prefs.stopAfterSec * 1000L
        targets.forEach { setTouchable(it, false) } // تمرير اللمسات للتطبيق الذي خلفها
        refreshPanel()
        countdown(prefs.startDelaySec)
    }

    private fun countdown(left: Int) {
        if (!clicking) return
        if (left <= 0) {
            clickStart = SystemClock.elapsedRealtime()
            tvCount?.text = "0"
            handler.post(tick)
            return
        }
        tvCount?.text = "⏳$left"
        handler.postDelayed({ countdown(left - 1) }, 1000)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!clicking) return
            val svc = ClickerAccessibilityService.instance
            if (svc == null) { toast(R.string.need_a11y); stopClicking(); return }
            if (stopAfterMs > 0 && SystemClock.elapsedRealtime() - clickStart >= stopAfterMs) {
                stopClicking(); return
            }
            val interval = prefs.intervalMs
            if (targets.isNotEmpty()) {
                val t = targets[cursor % targets.size]
                cursor = (cursor + 1) % targets.size
                val (x, y) = center(t)
                if (svc.tap(x, y, (interval / 2).coerceIn(1L, 40L))) {
                    session++
                    tvCount?.text = session.toString()
                }
            }
            if (maxClicks > 0 && session >= maxClicks) { stopClicking(); return }
            handler.postDelayed(this, interval)
        }
    }

    private fun stopClicking() {
        if (!clicking) return
        clicking = false
        handler.removeCallbacksAndMessages(null)
        prefs.lastSession = session
        prefs.totalClicks = prefs.totalClicks + session
        targets.forEach { setTouchable(it, true) }
        savePoints()
        refreshPanel()
    }
}
